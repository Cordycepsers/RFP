"""
Notification modules for Proposaland opportunity monitoring.
"""

from .email_notifier import EmailNotifier

__all__ = ['EmailNotifier']

