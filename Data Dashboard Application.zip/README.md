
  # Data Dashboard Application

  This is a code bundle for Data Dashboard Application. The original project is available at https://www.figma.com/design/WM7vJl1EE8XVXMm7oAz0uk/Data-Dashboard-Application.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  